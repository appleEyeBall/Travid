package com.oolase.travid;

public class Util {
    public static String LOG_TAG = "LOG_TAG";
}
